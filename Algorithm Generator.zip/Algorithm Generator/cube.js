c = document.getElementById("cube");
d = c.getContext("2d");

var screen = 0;
var code = ["#000000", "#ffffff", "#ffff00", "#00ff00", "#ff0000", "#0000ff", "#ffaa00", "#444444"];
var colors = [1,1,1,1,1,1,1,1,1,2,2,2,2,2,2,2,2,2,3,3,3,3,3,3,3,3,3,4,4,4,4,4,4,4,4,4,5,5,5,5,5,5,5,5,5,6,6,6,6,6,6,6,6,6];
var prevColors = [];
var solveColors = [];
var color = 0;
var strings = ["R", "L", "F", "B", "U", "D", "R'", "L'", "F'", "B'", "U'", "D'", "R2", "L2", "F2", "B2", "U2", "D2", "r", "l", "f", "b", "u", "d", "r'", "l'", "f'", "b'", "u'", "d'", "r2", "l2", "f2", "b2", "u2", "d2", "M", "E", "S", "M'", "E'", "S'", "M2", "E2", "S2", "x", "y", "z", "x'", "y'", "z'", "x2", "y2", "z2"];
var strings2 = ["ULB", "UB", "URB", "UL", "U", "UR", "ULF", "UF", "URF", "FLU", "FU", "FRU", "FL", "F", "FR", "FLD", "FD", "FRD", "RFU", "RU", "RUB", "RF", "R", "RB", "RFD", "RD", "RBD"];
var movesAllowed = [1, 1, 1, 1, 1, 1, 1, 1, 1,1];
var moveOs = [1, 2, 3, 4, 5, 6, 7,  8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27];
var mCode = ["R", "U", "F", "L", "D", "B", "M", "E", "S", "Q", "T", "G", "K", "C", "A", "N", "5", "6", "1", "V", "H", "2", "3", "4", "7", "8", "9"];
var moves = ["R","U", "F", "L", "D", "B", "M", "E", "S","R'", "U'", "F'", "L'", "D'", "B'", "M'", "E'", "S'", "R2", "U2", "F2", "L2", "D2", "B2", "M2", "E2", "S2"];
var mMoves = 10;
var solutions = [];
var moveStr = ["R", "U", "F", "L", "D", "B", "M", "E", "S"];
var sR = 1;
var timeout = 10;


function fixMCode(input) {
	var output = "";
	for (var j = 0; j < input.length; j++) { 
	for (var i = 0; i < mCode.length; i++) {
		if (input.charAt(j) === mCode[i]) {
			output += moves[i];
		}
	}
	}
	return output;
}


function quad(x1, y1, x2, y2, direction) {
	d.beginPath();
	if (direction == 1) {
		d.moveTo(x1, y1);
		d.lineTo(x1, (((y2-y1)/5)*4)+y1);
		d.lineTo(x2, y2);
		d.lineTo(x2, ((y2-y1)/5)+y1);
		d.lineTo(x1, y1);
	} else if (direction == 2) {
		d.moveTo(x1, ((y2-y1)/5)+y1);
		d.lineTo(x1, y2);
		d.lineTo(x2, (((y2-y1)/5)*4)+y1);
		d.lineTo(x2, y1);
		d.lineTo(x1, ((y2-y1)/5)+y1);
	} else if (direction == 3) {
		d.moveTo(x1+((x2-x1)/2), y1);
		d.lineTo(x1, y1+((y2-y1)/2));
		d.lineTo(x1+((x2-x1)/2), y2);
		d.lineTo(x2, y1+((y2-y1)/2));
		d.lineTo(x1+((x2-x1)/2), y1);
	}
	d.fill();
	d.stroke();
}
setInterval(function() {
	render();
	var colorCount = [0, 0, 0, 0, 0, 0, 0];
	for (var i = 0; i < colors.length; i++) {
		colorCount[colors[i]]++;
	}

	if (timeout < 10) {
		timeout++;
	}
}, 100);
d.fillStyle = "#333333";
d.strokeStyle = "#000000";
quad(25, 80, 250, 420, 1);
quad(250, 80, 475, 420, 2);
quad(25, 10, 475, 148, 3);

function solve() {
	solutions = [];
	for (var i = 0; i < colors.length; i++) {
		solveColors[i] = colors[i];
	}
//	console.log(solveColors);
	var exit = false;
	var L = 1;
	var test = "";
	var notL = l;
	var numMoves = moveOs.length / 3;
    var start = window.performance.now();

	for (var k = 0; k <= mMoves; k++) {

		for (var l = 0; l <= Math.pow(moveOs.length, k); l++) {			
				L = l;
				for (var i = 0; i < k - 1; i++) {
					if ((L % moveOs.length)%numMoves === ((Math.floor(L/moveOs.length)) % moveOs.length)%numMoves) {
						exit = true;
						break;
					}
					L = Math.floor(L / moveOs.length);
				}
			if (!exit) {
				test = "";
				notL = l;
				for (var i = 0; i < k; i++) {
						test = test + mCode[moveOs[ (notL % moveOs.length)] - 1];
						notL = Math.floor(notL / moveOs.length);
				}

				if (runTest(test)) {
					solutions.push(test);
				}
				//console.log(fixMCode(test));
			} else {
				exit = false;
			}
			for (var i = 0; i < colors.length; i++) {
				colors[i] = solveColors[i];
			}

			if (solutions.length >= sR) {
				break;
			}
		}
		if (solutions.length >= sR) {
			break;
		}
	}
	console.log(solutions);
//	console.log(color);
	var stop = window.performance.now();
    console.log("total time = " + (stop - start));
}

function runMoves(moves) {
	for (var i = 0; i < moves.length; i++) {
		if (moves.charAt(i) === "R") {
			r();
		} else if (moves.charAt(i) === "U") {
			u();
		} else if (moves.charAt(i) === "F") {
			f();
		} else if (moves.charAt(i) === "L") {
			l();
		} else if (moves.charAt(i) === "D") {
			D();
		} else if (moves.charAt(i) === "B") {
			b();
		} else if (moves.charAt(i) === "Q") {
			ri();
		} else if (moves.charAt(i) === "T") {
			ui();
		} else if (moves.charAt(i) === "G") {
			fi();
		} else if (moves.charAt(i) === "K") {
			li();
		} else if (moves.charAt(i) === "C") {
			di();
		} else if (moves.charAt(i) === "A") {
			bi();
		} else if (moves.charAt(i) === "1") {
			r2();
		} else if (moves.charAt(i) === "V") {
			u2();
		} else if (moves.charAt(i) === "H") {
			f2();
		} else if (moves.charAt(i) === "2") {
			l2();
		} else if (moves.charAt(i) === "3") {
			d2();
		} else if (moves.charAt(i) === "4") {
			b2();
		} else if (moves.charAt(i) === "M") {
			m();
		} else if (moves.charAt(i) === "S") {
			S();
		} else if (moves.charAt(i) === "E") {
			e();
		} else if (moves.charAt(i) === "N") {
			mi();
		} else if (moves.charAt(i) === "6") {
			s();
		} else if (moves.charAt(i) === "5") {
			ei();
		} else if (moves.charAt(i) === "7") {
			m2();
		} else if (moves.charAt(i) === "9") {
			s2();
		} else if (moves.charAt(i) === "8") {
			e2();
		}
	}
}

function runTest(test) {
	runMoves(test);
	for (var i = 0; i < colors.length; i++) {
		while (colors[i] === 7) {
			i++;
		}
			if (i == 8 || i == 17 || i == 26 || i == 35 || i == 44 || i == 53) {
				if (colors[i] != colors[i-1] && colors[i-1] != 7) {
					return false;
				}
			} else if (colors[i] != colors[i+1] && colors[i+1] != 7) {
				return false;
			}
	}
	return true;
}

function render() {
	d.fillStyle = code[colors[9]];
	quad(25+(150), 10, 175+(150), 56, 3);

	d.fillStyle = code[colors[10]];
	quad(25+(75), 33, 175+(75), 79, 3);

	d.fillStyle = code[colors[11]];
	quad(250, 33, 175+(225), 79, 3);

	d.fillStyle = code[colors[12]];
	quad(25, 56, 175, 102, 3);

	d.fillStyle = code[colors[13]];
	quad(175, 56, 175+(150), 102, 3);

	d.fillStyle = code[colors[14]];
	quad(325, 56, 175+(300), 102, 3);

	d.fillStyle = code[colors[15]];
	quad(25+(75), 79, 175+(75), 125, 3);

	d.fillStyle = code[colors[16]];
	quad(250, 79, 175+(225), 125, 3);

	d.fillStyle = code[colors[17]];
	quad(25+(150), 102, 175+(150), 148, 3);

	d.fillStyle = code[colors[18]];
	quad(400, 167, 475, 280, 2);

	d.fillStyle = code[colors[19]];
	quad(400, 254, 475, 375, 2);

	d.fillStyle = code[colors[20]];
	quad(325, 103, 400, 216, 2);

	d.fillStyle = code[colors[21]];
	quad(325, 194, 400, 306, 2);

	d.fillStyle = code[colors[22]];
	quad(325, 278, 400, 398, 2);

	d.fillStyle = code[colors[23]];
	quad(400, 80, 475, 193, 2);

	d.fillStyle = code[colors[24]];
	quad(250, 126, 325, 239, 2);

	d.fillStyle = code[colors[25]];
	quad(250, 216, 325, 325, 2);

	d.fillStyle = code[colors[26]];
	quad(250, 301, 325, 420, 2);

	d.fillStyle = code[colors[27]];
	quad(25, 80, 100, 193, 1);

	d.fillStyle = code[colors[28]];
	quad(25, 171, 100, 279, 1);

	d.fillStyle = code[colors[29]];
	quad(25, 257, 100, 374, 1);

	d.fillStyle = code[colors[30]];
	quad(100, 103, 175, 216, 1);

	d.fillStyle = code[colors[31]];
	quad(100, 194, 175, 304, 1);

	d.fillStyle = code[colors[32]];
	quad(100, 279, 175, 398, 1);

	d.fillStyle = code[colors[33]];
	quad(175, 126, 250, 239, 1);

	d.fillStyle = code[colors[34]];
	quad(175, 216, 250, 325, 1);

	d.fillStyle = code[colors[35]];
	quad(175, 303, 250, 420, 1);

	d.font = "30px Arial";

	for (var i = 0; i < 54; i++) {
		d.fillStyle = "#666666";
		d.fillRect(550+(55*(i%6)),30+(50*Math.floor(i/6)), 45, 45);
		d.fillStyle = "#000000";
		d.fillText(strings[i], 550+(55*(i%6)),65+(50*Math.floor(i/6)));
}
	d.fillStyle = "#888888";
	d.fillRect(5, 425, 515, 175);
	d.font = "20px Arial";
	for (var i = 0; i < 27; i++) {
		d.fillStyle = code[colors[number(i+1)]];
		d.fillRect(10 + (57 * (i % 9)), 430 + (57 * Math.floor(i / 9)), 50, 50);
		d.fillStyle = "#000000";
		d.fillText(strings2[i], 10+ (57*(i%9)), 460 + (57 * Math.floor(i / 9)));
	}
	d.fillStyle = "#bbbbbb";
	d.fillRect(900, 0, 450, 600);
	d.fillStyle = "#33ee33";
	d.strokeStyle = "#11aa11";
	d.fillRect(925, 512.5, 200, 75);
	d.lineWidth = 3;
	d.strokeRect(925, 512.5, 200, 75);
	d.font = "50px Impact";
	d.fillStyle = "#000000";
	d.fillText("Run", 985, 570);
	d.fillStyle = "#999999";
	d.fillRect(1150, 512.5, 150, 75);
	d.strokeStyle = "#333333";
	d.strokeRect(1150, 512.5, 150, 75);
	d.fillStyle = "#222222";
	d.font = "40px Impact";
	d.fillText("Settings", 1155, 565);
	d.font = "60px Impact";
	if (screen === 0) {
		d.fillText("Solutions", 1000, 60);
		d.font = "50px Impact";
		var solutiona = "";
		for (var i = 0; i < solutions.length; i++) {
			solutiona = "";
			for (var j = 0; j < solutions[i].length; j++) {
				solutiona = solutiona + " " + fixMCode(solutions[i].charAt(j));
			} 
			d.fillText(solutiona, 1000, 150 + (i*75));
		}
		
	} else {
		d.fillText("Settings", 1000, 60);
		d.font = "40px Impact";
		d.fillText("Max Moves: " + mMoves, 920, 120);
		d.fillText("Solutions to find: " + sR, 920, 200);
		d.fillText("Moves Allowed:", 920, 280);
		d.fillStyle = "#00cc00";
		d.beginPath();
		d.moveTo(1175, 100);
		d.lineTo(1187.5, 80);
		d.lineTo(1200, 100);
		d.lineTo(1175, 100);
		d.stroke();
		d.fill();
		d.beginPath();
		d.moveTo(1175, 120);
		d.lineTo(1187.5, 140);
		d.lineTo(1200, 120);
		d.lineTo(1175, 120);
		d.stroke();
		d.fill();
		d.beginPath();
		d.moveTo(1250, 170);
		d.lineTo(1262.5, 150);
		d.lineTo(1275, 170);
		d.lineTo(1250, 170);
		d.stroke();
		d.fill();
		d.beginPath();
		d.moveTo(1250, 190);
		d.lineTo(1262.5, 210);
		d.lineTo(1275, 190);
		d.lineTo(1250, 190);
		d.stroke();
		d.fill();
		movesAllowed = [0, 0, 0, 0, 0, 0, 0, 0, 0];
		for (var i = 0; i < moveOs.length; i++) {
			for (var j = 0; j < moveStr.length; j++) {
				if (moves[moveOs[i] - 1] === moveStr[j]) {
					movesAllowed[j] = 1;
				}
			}
		}
		for (var i = 0; i < 9; i++) {
			if (movesAllowed[i] == 1) {
				d.fillStyle = "#00aa00";
			} else {
				d.fillStyle = "#aa0000";
			}
			d.fillRect(950 + ((i%3) * 120), 300 + (Math.floor(i / 3) * 75), 50, 50);
			d.fillStyle = "#222222";
			d.font = "30px Arial";
			d.fillText(moveStr[i], 950 + (i%3 * 120), 330 + (Math.floor(i / 3) * 75));
		}
	}
	d.strokeStyle = "#000000";
	d.lineWidth = 1;
}


function r() {
	prevColors = [];
	for (var i = 0; i < colors.length; i++) {
		prevColors.push(colors[i]);
	}
		
	colors[20] = prevColors[25];
	colors[25] = prevColors[22];
	colors[18] = prevColors[20];
	colors[22] = prevColors[18];//*/

	colors[23] = prevColors[24];
	colors[24] = prevColors[26];
	colors[26] = prevColors[19];
	colors[19] = prevColors[23];//*/

	colors[34] = prevColors[5];
	colors[16] = prevColors[34];
	colors[46] = prevColors[16];
	colors[5] = prevColors[46];//*/

	colors[33] = prevColors[2];
	colors[14] = prevColors[33];
	colors[47] = prevColors[14];
	colors[2] = prevColors[47];//*/
	colors[35] = prevColors[8];
	colors[17] = prevColors[35];
	colors[45] = prevColors[17];
	colors[8] = prevColors[45];//*/
}

function f() {
	prevColors = [];
	for (var i = 0; i < colors.length; i++) {
		prevColors.push(colors[i]);
	}

	colors[37] = prevColors[1];
	colors[1] = prevColors[25];
	colors[25] = prevColors[15];
	colors[15] = prevColors[37];//*/

	colors[34] = prevColors[30];
	colors[28] = prevColors[32];
	colors[30] = prevColors[28];
	colors[32] = prevColors[34];//*/

	colors[0] = prevColors[26];
	colors[26] = prevColors[17];
	colors[17] = prevColors[36];
	colors[36] = prevColors[0];//*/

	colors[24] = prevColors[12];
	colors[2] = prevColors[24];
	colors[38] = prevColors[2];
	colors[12] = prevColors[38];//*/

	colors[35] = prevColors[33];
	colors[33] = prevColors[27];
	colors[29] = prevColors[35];
	colors[27] = prevColors[29];//*/
}
function u() {
	prevColors = [];
	for (var i = 0; i < colors.length; i++) {
		prevColors.push(colors[i]);
	}

	colors[14] = prevColors[9];
	colors[17] = prevColors[14];
	colors[12] = prevColors[17];
	colors[9] = prevColors[12];//*/

	colors[15] = prevColors[16];
	colors[16] = prevColors[11];
	colors[11] = prevColors[10];
	colors[10] = prevColors[15];//*/

	colors[24] = prevColors[45];
	colors[27] = prevColors[24];
	colors[45] = prevColors[42];
	colors[42] = prevColors[27];//*/

	colors[23] = prevColors[51];
	colors[33] = prevColors[23];
	colors[36] = prevColors[33];
	colors[51] = prevColors[36];//*/

	colors[20] = prevColors[48];
	colors[30] = prevColors[20];
	colors[48] = prevColors[40];
	colors[40] = prevColors[30];//*/
}

function l() {
	prevColors = [];
	for (var i = 0; i < colors.length; i++) {
		prevColors.push(colors[i]);
	}

	colors[40] = prevColors[43];
	colors[37] = prevColors[40];
	colors[39] = prevColors[37];
	colors[43] = prevColors[39];//*/

	colors[10] = prevColors[52];
	colors[28] = prevColors[10];
	colors[3] = prevColors[28];
	colors[52] = prevColors[3];//*/

	colors[12] = prevColors[51];
	colors[29] = prevColors[12];
	colors[6] = prevColors[29];
	colors[51] = prevColors[6];//*/

	colors[9] = prevColors[53];
	colors[27] = prevColors[9];
	colors[0] = prevColors[27];
	colors[53] = prevColors[0];//*/

	colors[42] = prevColors[44];
	colors[36] = prevColors[42];
	colors[38] = prevColors[36];
	colors[44] = prevColors[38];//*/
}

function b() {
	prevColors = [];
	for (var i = 0; i < colors.length; i++) {
		prevColors.push(colors[i]);
	}

	colors[52] = prevColors[48];
	colors[48] = prevColors[46];
	colors[46] = prevColors[50];
	colors[50] = prevColors[52];//*/

	colors[51] = prevColors[45];
	colors[53] = prevColors[51];
	colors[47] = prevColors[53];
	colors[45] = prevColors[47];//*/

	colors[18] = prevColors[7];
	colors[11] = prevColors[18];
	colors[43] = prevColors[11];
	colors[7] = prevColors[43];//*/

	colors[14] = prevColors[19];
	colors[42] = prevColors[14];
	colors[6] = prevColors[42];
	colors[19] = prevColors[6];//*/

	colors[9] = prevColors[23];
	colors[44] = prevColors[9];
	colors[8] = prevColors[44];
	colors[23] = prevColors[8];//*/
}
function D() {
	prevColors = [];
	for (var i = 0; i < colors.length; i++) {
		prevColors.push(colors[i]);
	}

	colors[1] = prevColors[3];
	colors[5] = prevColors[1];
	colors[7] = prevColors[5];
	colors[3] = prevColors[7];//*/

	colors[0] = prevColors[6];
	colors[2] = prevColors[0];
	colors[8] = prevColors[2];
	colors[6] = prevColors[8];//*/

	colors[22] = prevColors[32];
	colors[50] = prevColors[22];
	colors[39] = prevColors[50];
	colors[32] = prevColors[39];//*/

	colors[19] = prevColors[35];
	colors[53] = prevColors[19];
	colors[38] = prevColors[53];
	colors[35] = prevColors[38];//*/

	colors[26] = prevColors[29];
	colors[47] = prevColors[26];
	colors[44] = prevColors[47];
	colors[29] = prevColors[44];//*/
}

function m() {
	prevColors = [];
	for (var i = 0; i < colors.length; i++) {
		prevColors.push(colors[i]);
	}

	colors[31] = prevColors[13];
	colors[4] = prevColors[31];
	colors[49] = prevColors[4];
	colors[13] = prevColors[49];//*/

	colors[15] = prevColors[48];
	colors[32] = prevColors[15];
	colors[7] = prevColors[32];
	colors[48] = prevColors[7];//*/

	colors[11] = prevColors[50];
	colors[30] = prevColors[11];
	colors[1] = prevColors[30];
	colors[50] = prevColors[1];//*/
}

function e() {
	prevColors = [];
	for (var i = 0; i < colors.length; i++) {
		prevColors.push(colors[i]);
	}

	colors[31] = prevColors[41];
	colors[21] = prevColors[31];
	colors[49] = prevColors[21];
	colors[41] = prevColors[49];//*/

	colors[18] = prevColors[34];
	colors[52] = prevColors[18];
	colors[37] = prevColors[52];
	colors[34] = prevColors[37];//*/

	colors[25] = prevColors[28];
	colors[46] = prevColors[25];
	colors[43] = prevColors[46];
	colors[28] = prevColors[43];//*/
}

function s() {
	prevColors = [];
	for (var i = 0; i < colors.length; i++) {
		prevColors.push(colors[i]);
	}

	colors[13] = prevColors[21];
	colors[41] = prevColors[13];
	colors[4] = prevColors[41];
	colors[21] = prevColors[4];//*/

	colors[5] = prevColors[39];
	colors[20] = prevColors[5];
	colors[10] = prevColors[20];
	colors[39] = prevColors[10];//*/

	colors[3] = prevColors[40];
	colors[22] = prevColors[3];
	colors[16] = prevColors[22];
	colors[40] = prevColors[16];//*/
}

function number(input) {
	if (input == 1) {
		return 9;
	} else if (input == 2) {
		return 11;
	} else if (input == 3) {
		return 14;
	} else if (input == 4) {
		return 10;
	} else if (input == 5) {
		return 13;
	} else if (input == 6) {
		return 16;
	} else if (input == 7) {
		return 12;
	} else if (input == 8) {
		return 15;
	} else if (input == 9) {
		return 17;
	} else if (input == 10) {
		return 27;
	} else if (input == 11) {
		return 30;
	} else if (input == 12) {
		return 33;
	} else if (input == 13) {
		return 28;
	} else if (input == 14) {
		return 31;
	} else if (input == 15) {
		return 34;
	} else if (input == 16) {
		return 29;
	} else if (input == 17) {
		return 32;
	} else if (input == 18) {
		return 35;
	} else if (input == 19) {
		return 24;
	} else if (input == 20) {
		return 20;
	} else if (input == 21) {
		return 23;
	} else if (input == 22) {
		return 25;
	} else if (input == 23) {
		return 21;
	} else if (input == 24) {
		return 18;
	} else if (input == 25) {
		return 26;
	} else if (input == 26) {
		return 22;
	} else if (input == 27) {
		return 19;
	}
}

function ri() {
prevColors = [];
	for (var i = 0; i < colors.length; i++) {
		prevColors.push(colors[i]);
	}
		
	colors[25] = prevColors[20];
	colors[22] = prevColors[25];
	colors[20] = prevColors[18];
	colors[18] = prevColors[22];//*/

	colors[24] = prevColors[23];
	colors[26] = prevColors[24];
	colors[19] = prevColors[26];
	colors[23] = prevColors[19];//*/

	colors[5] = prevColors[34];
	colors[34] = prevColors[16];
	colors[16] = prevColors[46];
	colors[46] = prevColors[5];//*/

	colors[2] = prevColors[33];
	colors[33] = prevColors[14];
	colors[14] = prevColors[47];
	colors[47] = prevColors[2];//*/
	colors[8] = prevColors[35];
	colors[35] = prevColors[17];
	colors[17] = prevColors[45];
	colors[45] = prevColors[8];//*/
}
function li() {
	prevColors = [];
	for (var i = 0; i < colors.length; i++) {
		prevColors.push(colors[i]);
	}

	colors[43] = prevColors[40];
	colors[40] = prevColors[37];
	colors[37] = prevColors[39];
	colors[39] = prevColors[43];//*/

	colors[52] = prevColors[10];
	colors[10] = prevColors[28];
	colors[28] = prevColors[3];
	colors[3] = prevColors[52];//*/

	colors[51] = prevColors[12];
	colors[12] = prevColors[29];
	colors[29] = prevColors[6];
	colors[6] = prevColors[51];//*/

	colors[53] = prevColors[9];
	colors[9] = prevColors[27];
	colors[27] = prevColors[0];
	colors[0] = prevColors[53];//*/

	colors[44] = prevColors[42];
	colors[42] = prevColors[36];
	colors[36] = prevColors[38];
	colors[38] = prevColors[44];//*/
}
function fi() {
prevColors = [];
	for (var i = 0; i < colors.length; i++) {
		prevColors.push(colors[i]);
	}

	colors[1] = prevColors[37];
	colors[25] = prevColors[1];
	colors[15] = prevColors[25];
	colors[37] = prevColors[15];//*/

	colors[30] = prevColors[34];
	colors[32] = prevColors[28];
	colors[28] = prevColors[30];
	colors[34] = prevColors[32];//*/

	colors[26] = prevColors[0];
	colors[17] = prevColors[26];
	colors[36] = prevColors[17];
	colors[0] = prevColors[36];//*/

	colors[12] = prevColors[24];
	colors[24] = prevColors[2];
	colors[2] = prevColors[38];
	colors[38] = prevColors[12];//*/

	colors[33] = prevColors[35];
	colors[27] = prevColors[33];
	colors[35] = prevColors[29];
	colors[29] = prevColors[27];//*/
}
function bi() {
	prevColors = [];
	for (var i = 0; i < colors.length; i++) {
		prevColors.push(colors[i]);
	}

	colors[48] = prevColors[52];
	colors[46] = prevColors[48];
	colors[50] = prevColors[46];
	colors[52] = prevColors[50];//*/

	colors[45] = prevColors[51];
	colors[51] = prevColors[53];
	colors[53] = prevColors[47];
	colors[47] = prevColors[45];//*/

	colors[7] = prevColors[18];
	colors[18] = prevColors[11];
	colors[11] = prevColors[43];
	colors[43] = prevColors[7];//*/

	colors[19] = prevColors[14];
	colors[14] = prevColors[42];
	colors[42] = prevColors[6];
	colors[6] = prevColors[19];//*/

	colors[23] = prevColors[9];
	colors[9] = prevColors[44];
	colors[44] = prevColors[8];
	colors[8] = prevColors[23];//*/
}
function ui() {
prevColors = [];
	for (var i = 0; i < colors.length; i++) {
		prevColors.push(colors[i]);
	}

	colors[9] = prevColors[14];
	colors[14] = prevColors[17];
	colors[17] = prevColors[12];
	colors[12] = prevColors[9];//*/

	colors[16] = prevColors[15];
	colors[11] = prevColors[16];
	colors[10] = prevColors[11];
	colors[15] = prevColors[10];//*/

	colors[45] = prevColors[24];
	colors[24] = prevColors[27];
	colors[42] = prevColors[45];
	colors[27] = prevColors[42];//*/

	colors[51] = prevColors[23];
	colors[23] = prevColors[33];
	colors[33] = prevColors[36];
	colors[36] = prevColors[51];//*/

	colors[48] = prevColors[20];
	colors[20] = prevColors[30];
	colors[40] = prevColors[48];
	colors[30] = prevColors[40];//*/
}
function di() {
	prevColors = [];
	for (var i = 0; i < colors.length; i++) {
		prevColors.push(colors[i]);
	}

	colors[3] = prevColors[1];
	colors[1] = prevColors[5];
	colors[5] = prevColors[7];
	colors[7] = prevColors[3];//*/

	colors[6] = prevColors[0];
	colors[0] = prevColors[2];
	colors[2] = prevColors[8];
	colors[8] = prevColors[6];//*/

	colors[32] = prevColors[22];
	colors[22] = prevColors[50];
	colors[50] = prevColors[39];
	colors[39] = prevColors[32];//*/

	colors[35] = prevColors[19];
	colors[19] = prevColors[53];
	colors[53] = prevColors[38];
	colors[38] = prevColors[35];//*/

	colors[29] = prevColors[26];
	colors[26] = prevColors[47];
	colors[47] = prevColors[44];
	colors[44] = prevColors[29];//*/
}

function r2() {
	prevColors = [];
	for (var i = 0; i < colors.length; i++) {
		prevColors.push(colors[i]);
	}
		
	colors[22] = prevColors[20];
	colors[18] = prevColors[25];
	colors[25] = prevColors[18];
	colors[20] = prevColors[22];//*/

	colors[26] = prevColors[23];
	colors[19] = prevColors[24];
	colors[24] = prevColors[19];
	colors[23] = prevColors[26];///*
	

	colors[5] = prevColors[16];
	colors[16] = prevColors[5];
	colors[34] = prevColors[46];
	colors[46] = prevColors[34];//*/

	colors[2] = prevColors[14];
	colors[14] = prevColors[2];
	colors[33] = prevColors[47];
	colors[47] = prevColors[33];//*/
	colors[8] = prevColors[17];
	colors[17] = prevColors[8];
	colors[35] = prevColors[45];
	colors[45] = prevColors[35];//*/
}
function l2() {
	prevColors = [];
	for (var i = 0; i < colors.length; i++) {
		prevColors.push(colors[i]);
	}

	colors[43] = prevColors[37];
	colors[37] = prevColors[43];
	colors[40] = prevColors[39];
	colors[39] = prevColors[40];//*/

	colors[3] = prevColors[10];
	colors[10] = prevColors[3];
	colors[28] = prevColors[52];
	colors[52] = prevColors[28];//*/

	colors[6] = prevColors[12];
	colors[12] = prevColors[6];
	colors[29] = prevColors[51];
	colors[51] = prevColors[29];//*/

	colors[0] = prevColors[9];
	colors[9] = prevColors[0];
	colors[27] = prevColors[53];
	colors[53] = prevColors[27];//*/

	colors[38] = prevColors[42];
	colors[42] = prevColors[38];
	colors[36] = prevColors[44];
	colors[44] = prevColors[36];//*/
}
function f2() {
prevColors = [];
	for (var i = 0; i < colors.length; i++) {
		prevColors.push(colors[i]);
	}

	colors[1] = prevColors[15];
	colors[15] = prevColors[1];
	colors[37] = prevColors[25];
	colors[25] = prevColors[37];//*/

	colors[28] = prevColors[34];
	colors[30] = prevColors[32];
	colors[32] = prevColors[30];
	colors[34] = prevColors[28];//*/

	colors[26] = prevColors[36];
	colors[36] = prevColors[26];
	colors[17] = prevColors[0];
	colors[0] = prevColors[17];//*/

	colors[38] = prevColors[24];
	colors[24] = prevColors[38];
	colors[2] = prevColors[12];
	colors[12] = prevColors[2];//*/

	colors[33] = prevColors[29];
	colors[29] = prevColors[33];
	colors[27] = prevColors[35];
	colors[35] = prevColors[27];//*/
}
function b2() {
	prevColors = [];
	for (var i = 0; i < colors.length; i++) {
		prevColors.push(colors[i]);
	}

	colors[48] = prevColors[50];
	colors[50] = prevColors[48];
	colors[52] = prevColors[46];
	colors[46] = prevColors[52];//*/

	colors[47] = prevColors[51];
	colors[51] = prevColors[47];
	colors[53] = prevColors[45];
	colors[45] = prevColors[53];//*/

	colors[43] = prevColors[18];
	colors[18] = prevColors[43];
	colors[7] = prevColors[11];
	colors[11] = prevColors[7];//*/

	colors[6] = prevColors[14];
	colors[14] = prevColors[6];
	colors[19] = prevColors[42];
	colors[42] = prevColors[19];//*/

	colors[8] = prevColors[9];
	colors[9] = prevColors[8];
	colors[23] = prevColors[44];
	colors[44] = prevColors[23];//*/
}
function u2() {
	prevColors = [];
	for (var i = 0; i < colors.length; i++) {
		prevColors.push(colors[i]);
	}

	colors[12] = prevColors[14];
	colors[14] = prevColors[12];
	colors[9] = prevColors[17];
	colors[17] = prevColors[9];//*/

	colors[16] = prevColors[10];
	colors[10] = prevColors[16];
	colors[11] = prevColors[15];
	colors[15] = prevColors[11];//*/

	colors[42] = prevColors[24];
	colors[24] = prevColors[42];
	colors[27] = prevColors[45];
	colors[45] = prevColors[27];//*/

	colors[36] = prevColors[23];
	colors[23] = prevColors[36];
	colors[51] = prevColors[33];
	colors[33] = prevColors[51];//*/

	colors[40] = prevColors[20];
	colors[20] = prevColors[40];
	colors[30] = prevColors[48];
	colors[48] = prevColors[30];//*/
}
function d2() {
	prevColors = [];
	for (var i = 0; i < colors.length; i++) {
		prevColors.push(colors[i]);
	}

	colors[7] = prevColors[1];
	colors[1] = prevColors[7];
	colors[3] = prevColors[5];
	colors[5] = prevColors[3];//*/

	colors[8] = prevColors[0];
	colors[0] = prevColors[8];
	colors[6] = prevColors[2];
	colors[2] = prevColors[6];//*/

	colors[39] = prevColors[22];
	colors[22] = prevColors[39];
	colors[32] = prevColors[50];
	colors[50] = prevColors[32];//*/

	colors[38] = prevColors[19];
	colors[19] = prevColors[38];
	colors[35] = prevColors[53];
	colors[53] = prevColors[35];//*/

	colors[44] = prevColors[26];
	colors[26] = prevColors[44];
	colors[29] = prevColors[47];
	colors[47] = prevColors[29];//*/
}
function mi() {
	prevColors = [];
	for (var i = 0; i < colors.length; i++) {
		prevColors.push(colors[i]);
	}

	colors[13] = prevColors[31];
	colors[31] = prevColors[4];
	colors[4] = prevColors[49];
	colors[49] = prevColors[13];//*/

	colors[48] = prevColors[15];
	colors[15] = prevColors[32];
	colors[32] = prevColors[7];
	colors[7] = prevColors[48];//*/

	colors[50] = prevColors[11];
	colors[11] = prevColors[30];
	colors[30] = prevColors[1];
	colors[1] = prevColors[50];//*/
}
function si() {
	s();
}
function S() {
	prevColors = [];
	for (var i = 0; i < colors.length; i++) {
		prevColors.push(colors[i]);
	}

	colors[21] = prevColors[13];
	colors[13] = prevColors[41];
	colors[41] = prevColors[4];
	colors[4] = prevColors[21];//*/

	colors[39] = prevColors[5];
	colors[5] = prevColors[20];
	colors[20] = prevColors[10];
	colors[10] = prevColors[39];//*/

	colors[40] = prevColors[3];
	colors[3] = prevColors[22];
	colors[22] = prevColors[16];
	colors[16] = prevColors[40];//*/
}
function ei() {
	prevColors = [];
	for (var i = 0; i < colors.length; i++) {
		prevColors.push(colors[i]);
	}

	colors[41] = prevColors[31];
	colors[31] = prevColors[21];
	colors[21] = prevColors[49];
	colors[49] = prevColors[41];//*/

	colors[34] = prevColors[18];
	colors[18] = prevColors[52];
	colors[52] = prevColors[37];
	colors[37] = prevColors[34];//*/

	colors[28] = prevColors[25];
	colors[25] = prevColors[46];
	colors[46] = prevColors[43];
	colors[43] = prevColors[28];//*/
}
function m2() {
	prevColors = [];
	for (var i = 0; i < colors.length; i++) {
		prevColors.push(colors[i]);
	}

	colors[49] = prevColors[31];
	colors[31] = prevColors[49];
	colors[13] = prevColors[4];
	colors[4] = prevColors[13];//*/

	colors[7] = prevColors[15];
	colors[15] = prevColors[7];
	colors[48] = prevColors[32];
	colors[32] = prevColors[48];//*/

	colors[1] = prevColors[11];
	colors[11] = prevColors[1];
	colors[50] = prevColors[30];
	colors[30] = prevColors[50];//*/
}
function s2() {
	prevColors = [];
	for (var i = 0; i < colors.length; i++) {
		prevColors.push(colors[i]);
	}

	colors[4] = prevColors[13];
	colors[13] = prevColors[4];
	colors[21] = prevColors[41];
	colors[41] = prevColors[21];//*/

	colors[10] = prevColors[5];
	colors[5] = prevColors[10];
	colors[39] = prevColors[20];
	colors[20] = prevColors[39];//*/

	colors[16] = prevColors[3];
	colors[3] = prevColors[16];
	colors[22] = prevColors[40];
	colors[40] = prevColors[22];//*/
}
function e2() {
	prevColors = [];
	for (var i = 0; i < colors.length; i++) {
		prevColors.push(colors[i]);
	}

	colors[49] = prevColors[31];
	colors[31] = prevColors[49];
	colors[21] = prevColors[41];
	colors[41] = prevColors[21];//*/

	colors[37] = prevColors[18];
	colors[18] = prevColors[37];
	colors[52] = prevColors[34];
	colors[34] = prevColors[52];//*/

	colors[43] = prevColors[25];
	colors[25] = prevColors[43];
	colors[46] = prevColors[28];
	colors[28] = prevColors[46];//*/
}
function rwi() {
	r();
	r();
	r();
	m();
}
function lwi() {
	l();
	l();
	l();
	m();
	m();
	m();
}
function fwi() {
	f();
	f();
	f();
	s();
}
function bwi() {
	b();
	b();
	b();
	s();
	s();
	s();
}
function uwi() {
	u();
	u();
	u();
	e();
}
function dwi() {
	d();
	d();
	d();
	e();
	e();
	e();
}

function rw2() {
	r();
	r();
	m();
	m();
}
function lw2() {
	l();
	l();
	m();
	m();
}
function fw2() {
	f();
	f();
	s();
	s();
}
function bw2() {
	b();
	b();
	s();
	s();
}
function uw2() {
	u();
	u();
	e();
	e();
}
function dw2() {
	d();
	d();
	e();
	e();
}
function rw() {
	r();
	m();
	m();
	m();
}
function lw() {
	l();
	m();
}
function fw() {
	f();
	s();
	s();
	s();
}
function bw() {
	b();
	s();
}
function uw() {
	u();
	e();
	e();
	e();
}
function dw() {
	D();
	e();
}
document.addEventListener('click', function(event) {
	var mx = event.offsetX;
	var my = event.offsetY;
	var move = -1;
	if (mx - 1175 <= 25 && mx -1175 >= 0 && my >= 80 && my <= 100 && mMoves < 20) {
		mMoves++;
	}
	if (mx - 1175 <= 25 && mx -1175 >= 0 && my >= 120 && my <= 140 && mMoves > 1) {
		mMoves--;
	}
	if (mx - 1250 <= 25 && mx -1250 >= 0 && my >= 150 && my <= 170 && sR < 10) {
		sR++;
	}
	if (mx - 1250 <= 25 && mx -1250 >= 0 && my >= 190 && my <= 210 && sR > 1) {
		sR--;
	}

	if (mx - 925 <= 200 && mx - 925 >= 0 && my - 512.5 <= 75 && my - 512.5 >= 0 && timeout == 10) {
		timeout = -10;
		//console.log(colors);
		solve();
		screen = 0;
	}
	
	if (mx - 1150 <= 150 && mx - 1150 >= 0 && my - 512.5 <= 75 && my - 512.5 >= 0) {
		screen = 1;
	}
	
	for (var i = 0; i < 27; i++) {
		if (mx-(10 + (57 * (i % 9))) <= 50 && mx -(10 + (57 * (i % 9))) >=0 && my - ( 430 + (57 * Math.floor(i / 9))) <=50 && my - (430 + (57 * Math.floor(i / 9))) >= 0) {
			console.log(i);
			colors[number(i+1)]++;
			if (colors[number(i+1)] >= 8) {
				colors[number(i+1)] = 1;
			}
		}
	}
	for (var i = 0; i < 54; i++) {
		if (mx - (550+(55*(i%6))) <= 45 && mx - (550+(55*(i%6))) >= 0 && my - (60+(50*Math.floor(i/6))) <= 45 && my - (30+(50*Math.floor(i/6))) >= 0) {
			move = i;
		}
	}
	if (move === 0) {
		r();
	} else if (move === 6) {
		ri();
	} else if (move === 12) {
		r2();
	} else if (move === 1) {
		l();
	} else if (move === 7) {
		li();
	} else if (move === 13) {
		l2();
	} else if (move === 2) {
		f();
	} else if (move === 8) { 
		fi();
	} else if (move == 14) {
		f2();
	} else if (move === 3) {
		b();
	} else if (move === 9) {
		bi();
	} else if (move === 15) {
		b2();
	} else if (move == 4) {
		u();
	} else if (move == 10) {
		ui();
	} else if (move == 16) {
		u2();
	} else if (move == 5) {
		D();
	} else if (move == 11) {
		di();
	} else if (move == 17) {
		d2();
	} else if (move == 36) {
		m();
	} else if (move == 39) {
		mi();
	} else if (move == 42) {
		m2();
	} else if (move == 37) {
		e();
	} else if (move == 40) {
		ei();
	} else if (move == 43) {
		e2();
	} else if (move == 38) {
		S();
	} else if (move == 41) {
		si();
	} else if (move == 44) {
		s2();
	} else if (move == 18) {
		rw();
	} else if (move == 19) {
		lw();
	} else if (move == 20) {
		fw();
	} else if (move == 21) {
		bw();
	} else if (move == 22) {
		uw();
	} else if (move == 23) {
		dw();
	} else if (move == 24) {
		r();
		r();
		r();
		m();
	} else if (move == 25) {
		l();
		l();
		l();
		m();
		m();
		m();
	} else if (move == 26) {
		f();
		f();
		f();
		s();
	} else if (move == 27) {
		b();
		b();
		b();
		s();
		s();
		s();
	} else if (move == 28) {
		u();
		u();
		u();
		e();
	} else if (move == 29) {
		D();
		D();
		D();
		e();
		e();
		e();
	} else if (move == 30) {
		r();
		r();
		m();
		m();
	} else if (move == 31) {
		l();
		l();
		m();
		m();
	} else if (move == 32) {
		f();
		f();
		s();
		s();
	} else if (move == 33) {
		b();
		b();
		s();
		s();
	} else if (move == 34) {
		u();
		u();
		e();
		e();
	} else if (move == 35) {
		D();
		D();
		e();
		e();
	} else if (move == 45) {
		r();
		m();
		m();
		m();
		l();
		l();
		l();
	} else if (move == 48) {
		l();
		m();
		r();
		r();
		r();
	} else if (move == 47) {
		f();
		s();
		s();
		s();
		b();
		b();
		b();
	} else if (move == 50) {
		b();
		s();
		f();
		f();
		f();
	} else if (move == 46) {
		u();
		e();
		e();
		e();
		D();
		D();
		D();
	} else if (move == 49) {
		D();
		e();
		u();
		u();
		u();
	} else if (move == 53) {
		b();
		b();
		s();
		s();
		f();
		f();
	} else if (move == 52) {
		u();
		u();
		e();
		e();
		D();
		D();
	} else if (move == 51) {
		r();
		r();
		l();
		l();
		m();
		m();
	}
	for (var i = 0; i < 9; i++) {
		if (mx - (950 + ((i%3) * 120)) >= 0 && mx - (950 + ((i%3) * 120)) <= 50 && my - (300 + (Math.floor(i / 3) * 75)) >= 0 &&  my - (300 + (Math.floor(i / 3) * 75)) <= 50) {
			if (movesAllowed[i] == 0) {
				moveOs.splice(Math.ceil(moveOs.length / 3) , 0, i + 1);
				moveOs.splice(Math.ceil(moveOs.length / 3) * 2, 0, i + 10);
				moveOs.splice(Math.ceil(moveOs.length / 3) * 3, 0, i + 19);
			} else {
				for (var j = 0; j < moveOs.length; j++) {
					if (moveOs[j] == i + 1 || moveOs[j] == i + 10 || moveOs[j] == i + 19) {
						moveOs.splice(j, 1);
					}
				}
			}
		}
	}
});


