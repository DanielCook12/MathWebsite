var c = document.getElementById("main");
var d = c.getContext("2d");
var px = 700;
var bulletsX = [];
var bulletsY = [];
var enemiesX = [];
var enemiesY = [];
var enemiesD = [];
var enemiesT = [];
var enemiesBX = [];
var enemiesBY = [];
var reload = 0;
var levels = ["10101010101010111111001001110110111000000200002000020003000300001010101110001010220103001003"];
var levelRunning = 1;
var levelPlace = 0;
var enemyGo = 0;
var enemyReload = 0;
var gameOver = false;
setInterval(function() {
	update();
	render();
}, 30);

function doGameOver() {
	 bulletsX = [];
	 bulletsY = [];
	 enemiesX = [];
	 enemiesY = [];
	 enemiesD = [];
	 enemiesT = [];
	 enemiesBX = [];
	 enemiesBY = [];
	 enemyGo = 0;
	 levelRunning = 0;
	gameOver = true;
}

function Enemy(t) {
	enemiesX[enemiesX.length] = 25;
	enemiesY[enemiesY.length] = 25;
	enemiesD[enemiesD.length] = 1;
	enemiesT[enemiesT.length] = t;
}

function level(level) {
	if (levels[level-1].charAt(levelPlace+1) === "1") {
		Enemy(1);
	}
	if (levels[level-1].charAt(levelPlace+1) === "2") {
		Enemy(2);
	}
	
	if (levels[level-1].charAt(levelPlace+1) === "3") {
		Enemy(3);
	}
	levelPlace+= 1;
}

function triangle(x1, y1, x2, y2, x3, y3, color) {
	d.fillStyle = color;
	d.beginPath();
	d.moveTo(x1, y1);
	d.lineTo(x2, y2);
	d.lineTo(x3, y3);
	d.lineTo(x1, y1);
	d.fill();
}

function render() {
	d.clearRect(0, 0, 1400, 900);
	
	// Render Player
	d.fillStyle = "#008800";
	triangle(px, 800, px+50, 800, px+25, 750, "#00ff00");
	
	// Render bullets
	for (var i = 0; i < bulletsX.length; i++) {
		d.fillRect(bulletsX[i]-2.5, bulletsY[i] - 40, 5, 5);
	}
	
	// Render enemy bullets
	for (var i = 0; i < enemiesBX.length; i++) {
		d.fillStyle = "#0000cc";
		d.fillRect(enemiesBX[i]-2.5, enemiesBY[i] - 40, 5, 5);
	}
	
	// Render Enemies
	for (var i = 0; i < enemiesX.length; i++) {
		if (enemiesT[i] == 1) {
			d.fillStyle = "#cc0000";
		} else if (enemiesT[i] == 2) {
			d.fillStyle = "#00cccc";
		} else if (enemiesT[i] == 3) {
			d.fillStyle = "#0000cc";
		}
		d.beginPath();
		d.arc(enemiesX[i], enemiesY[i], 25, 0, Math.PI*2);
		d.fill();
	}
	
	if (gameOver) {
		d.font = "80px Arial";
		d.fillText("Game Over", 500, 400);
	}
 }

function shoot() {
	var i = bulletsX.length;
	bulletsX[i] = px+25;
	bulletsY[i] = 800;
}

function enemyShoot(x, y) {
	var i = enemiesBX.length;
	enemiesBX[i] = x+25;
	enemiesBY[i] = y;
}

function update() {
	//Update bullets
	if (reload != 0) {
		reload--;
	}
	for (var i = 0; i < bulletsX.length; i++) {
		bulletsY[i] -= 10;
		if (bulletsY[i] <= 40) {
			bulletsX.splice(i, 1);
			bulletsY.splice(i, 1);
		}
	}


	// Update Enemies
	for (var i = 0; i < enemiesX.length; i++) {
		if (enemiesT[i] == 1) {
			enemiesX[i]+=12*enemiesD[i];
		} else if (enemiesT[i] == 2) {
			enemiesX[i]+= 18*enemiesD[i];
		} else if (enemiesT[i] == 3) {
			enemiesX[i]+= 8*enemiesD[i];
			if (enemyReload >= 25) {
				enemyShoot(enemiesX[i] - 10, enemiesY[i] + 25);
			}
		}
		if (enemiesX[i] > 1350 || enemiesX[i] < 25) {
			enemiesY[i] += 50;
			enemiesD[i] *= -1;
		}
		for (var j = 0; j <= bulletsX.length; j++) {
			if (enemiesX[i] - bulletsX[j] <= 35 && enemiesX[i] - bulletsX[j] >= -35 && enemiesY[i] - bulletsY[j] <= 35 && enemiesY[i] - bulletsY[j] >= -35) {
				enemiesX.splice(i, 1);
				enemiesY.splice(i, 1);
				enemiesD.splice(i, 1);
				enemiesT.splice(i, 1);
				bulletsX.splice(j, 1);
				bulletsY.splice(j, 1);
			}
		}
	}
	enemyGo++;
	if (levelRunning && enemyGo == 7) {
		level(levelRunning);
		enemyGo = 0;
	}
	
	// Update enemy bullets
		enemyReload++;
		if (enemyReload >= 26) {
			enemyReload = 0;
		}

	for (var i = 0; i < enemiesBX.length; i++) {
		enemiesBY[i] += 10;
		if (bulletsY[i] >= 900) {
			enemiesBX.splice(i, 1);
			enemiesBX.splice(i, 1);
		}
		if (enemiesBX[i] - px <= 50 && enemiesBX[i] - px >= -50 && enemiesBY[i] >= 800 && enemiesBY[i] <= 900) {
			doGameOver();
		}
	}
	
	
}

document.addEventListener('keydown', function(event) {
	var code = event.keyCode;
	if (code == 68 && px < 1350) {
		px+= 25;
	}
	if (code == 65 && px > 0) {
		px-= 25;
	}

	if (code == 32 && reload === 0) {
		shoot();
		reload += 25;
	}
});