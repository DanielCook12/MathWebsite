/*
	TODO:
	Home Screen - Shop, Play, Achivements, How to play, Credits
	Upgrades - Power-up chance, fire rate, lives, fuel, coin multipier, super power upgrades
	Powers - teleport, blast, super blast, 10s shield, ion blast
	Team
	Challenge - Control how many lives you have
	PvP
	Tokens - Increase the chance of a specific power up
	Save codes
*/


var c = document.getElementById("main");
var d = c.getContext("2d");
var px = 700;
var bulletsX = [];
var bulletsY = [];
var enemiesX = [];
var enemiesY = [];
var enemiesD = [];
var enemiesT = [];
var enemiesDistance = [];
var enemiesBX = [];
var enemiesBY = [];
var powerX = [];
var powerY = [];
var powerType = [];
var powers = [];
var fuel = 0;
var reload = 0;
var randLevel = "";
var levelParts = ["00000","00000","00000","00000","00000","00000", "01110", "10101", "01010", "11111", "11011", "11010", "01110", "10101", "01010", "11111", "11011", "11010", "01110", "10101", "01010", "11111", "11011", "11010", "12121" , "00100", "11100", "00111", "00200", "22222","40004", "20202", "02020", "00300", "11311",  "03300", "00400",  "01410", "31113", "43434", "01110", "10101", "01010", "11111", "11011", "11010", "12121" , "00100", "11100", "00111", "00200", "22222","40004","00000","00000","00000","00000","00000","00000", "01110", "10101", "01010", "11111", "11011", "11010", "01110", "10101", "01010", "11111", "11011", "11010", "01110", "10101", "01010", "11111", "11011", "11010", "12121" , "00100", "11100", "00111", "00200", "22222","40004", "20202", "02020", "00300", "11311",  "03300", "00400",  "01410", "31113", "43434", "01110", "10101", "01010", "11111", "11011", "11010", "12121" , "00100", "11100", "00111", "00200", "22222","40004", "20202", "02020", "00300","00000","00000","00000","00000","00000","00000", "01110", "10101", "01010", "11111", "11011", "11010", "01110", "10101", "01010", "11111", "11011", "11010", "01110", "10101", "01010", "11111", "11011", "11010", "12121" , "00100", "11100", "00111", "00200", "22222","40004", "20202", "02020", "00300", "11311",  "03300", "00400",  "01410", "31113", "43434", "01110", "10101", "01010", "11111", "11011", "11010", "12121" , "00100", "11100", "00111", "00200", "22222","40004","00000","00000","00000","00000","00000","00000", "01110", "10101", "01010", "11111", "11011", "11010", "01110", "10101", "01010", "11111", "11011", "11010", "01110", "10101", "01010", "11111", "11011", "11010", "12121" , "00100", "11100", "00111", "00200", "22222","40004", "20202", "02020", "00300", "11311",  "03300", "00400",  "01410", "31113", "43434", "01110", "10101", "01010", "11111", "11011", "11010", "12121" , "00100", "11100", "00111", "00200", "22222","40004", "20202", "02020", "00300", "11311", "00400", "04040", "01410", "41414", "40404", "14141", "03330", "13331", "31113", "43434",  "32323", "33033", "33333"];
var levels = ["00010101010101010111111001001110110111000000200002000020003000300001010101110001010220103001003",                     "0110011001100110003000110011001100110003000220022002200220003300030001110001110001110001111100220022", "0020020020020020020020020011111000000011111000000011111000000333000000011111000000333000000111110000001111100033300011111","0001111111111111111111111111111111111103301111111111111111111111111111111033011111111111111111111111111033011111111111111111111111113311111111111112", "001110011100111001110011100222002220022200333003330000000000000000000000000000000111000111000111000111000111000111000111000111000111000111000222000222000222000333000333", "04040404040404040404040000000110011001100110110000110110110110000110000110110110000110000110000003300101003300101010100100100102222222000022222", "11101110100010100010101011100010000000101011100010101000000011101110111000101011100010111010000000111010101000101110100011101110111000111000101010100010001011101000101010000333000333000222", "2222220000000022222200000000222222000000001111111111111111100000000001111111111111100000030000000300003000003300004400000440000440003000300030003", "111111111111111111100000000330000000003300000000040400000004040000011111111111000220002200002200000300000404000000404000011111111111111000003000000300003", "2200220022002200000011111111111111111110000001111111111111111100003300000330000004041111111111000000333000033300002200220000000000000000004040404040400000300030002200011000111000000003000000000000000022000220002200022000114114114114114000303000111000111000111000141000141000141"];
var levelRunning = 1;
var levelPlace = 0;
var levelPassed = 0;
var enemyGo = 0;
var enemyReload = 0;
var gameOver = false;
var won = false;
var powersName = ["No power", "Dual Cannon", "Rapid Fire", "Shield", "Speed", "Flame Thrower", "Shrink", "Rockets", "Clone"];
var prevPWR = 0;
var score = 0;
var lives = 3;
setInterval(function() {
	update();
	render();
	fuel++;
}, 30);
randomLevel();
function randomLevel() {
	for (var i = Math.random()*20; i<40; i++) {
		randLevel = randLevel + "0" + levelParts[Math.floor(Math.random() * levelParts.length)];
	}
	console.log(randLevel);
}

function doGameOver() {
	powerX = [];
	powerY = [];
	powerType = [];
	 bulletsX = [];
	 bulletsY = [];
	 enemiesX = [];
	 enemiesY = [];
	 enemiesD = [];
	 enemiesT = [];
	 enemiesBX = [];
	 enemiesBY = [];
	 enemyGo = 0;
	 levelRunning = 0;
	 prevPWR = 0;
	 levelPlace = 0;
	 powers = [];
	gameOver = true;
}

function doWin() {
	 doGameOver();
	 levelPassed++;
	 won = true;
}

function Enemy(t) {
	enemiesX[enemiesX.length] = 25;
	enemiesY[enemiesY.length] = 25;
	enemiesD[enemiesD.length] = 1;
	enemiesT[enemiesT.length] = t;
	enemiesDistance[enemiesDistance.length] = 0; 
}

function doLevel(level) {
	if (level.charAt(levelPlace) === "1") {
		Enemy(1);
	}
	if (level.charAt(levelPlace) === "2") {
		Enemy(2);
	}
	
	if (level.charAt(levelPlace) === "3") {
		Enemy(3);
	}
	
	if (level.charAt(levelPlace) === "4") {
		Enemy(4);
	}
	levelPlace++;
}

function triangle(x1, y1, x2, y2, x3, y3, color) {
	d.fillStyle = color;
	d.beginPath();
	d.moveTo(x1, y1);
	d.lineTo(x2, y2);
	d.lineTo(x3, y3);
	d.lineTo(x1, y1);
	d.fill();
}

function render() {
	d.clearRect(0, 0, 1400, 900);
	
	// Render Player
	var clone = 0;
	if (powers.includes(8)) {
		clone = 1;
	}
	for (var i = 0; i < clone+1; i++) {
		if (fuel < 50) {
			d.fillStyle = "#00ff00";
			d.fillRect(px+60+(i*250), 800, 15, -1*(50-fuel));
		}

		if (powers.includes(6)) {
			triangle(px+15+(i*250), 800, px+35+(i*250), 800, px+25+(i*250), 780, "#00ff00");
		} else {
			triangle(px+(i*250), 800, px+50+(i*250), 800, px+25+(i*250), 750, "#00ff00");
		}
		if (powers.includes(3)) {
			d.strokeStyle = "#008800";
			d.beginPath();
			d.arc(px+25+(i*250), 785, 50, 0, Math.PI*3);
			d.lineWidth = 10;
			d.stroke();
			d.clearRect(px-30+(i*250), 800, 120, 50);
		}
		if (powers.includes(5)) {
			d.strokeStyle = "#ffaa00";
			d.beginPath();
			d.lineWidth = 10;
			d.moveTo(px-100+(i*250), 800);
			d.lineTo(px-80+(i*250), 745);
			d.lineTo(px-95+(i*250), 705);
			d.lineTo(px-70+(i*250), 710);
			d.lineTo(px-85+(i*250), 650);
			d.lineTo(px-65+(i*250), 670);
			d.lineTo(px-70+(i*250), 610);
			d.lineTo(px-40+(i*250), 650);
			d.lineTo(px-55+(i*250), 570);
			d.lineTo(px-15+(i*250), 630);
			d.lineTo(px+20+(i*250), 520);
			d.lineTo(px+55+(i*250), 620);
			d.lineTo(px+90+(i*250), 570); 
			d.lineTo(px+80+(i*250), 650); 
			d.lineTo(px+120+(i*250), 610);
			d.lineTo(px+100+(i*250), 680);
			d.lineTo(px+125+(i*250), 650);
			d.lineTo(px+110+(i*250), 720);
			d.lineTo(px+140+(i*250), 705); 
			d.lineTo(px+120+(i*250), 745); 
			d.lineTo(px+150+(i*250), 800); 
			d.stroke();
	}
	}


	// Render bullets
	if (powers.includes(7)) {
		for (var i = 0; i < bulletsX.length; i++) {
			d.fillRect(bulletsX[i]-7, bulletsY[i] - 40, 14, 40);
			triangle(bulletsX[i]-7, bulletsY[i]-40, bulletsX[i], bulletsY[i]-50, bulletsX[i]+7, bulletsY[i]-40);
			triangle(bulletsX[i]-14, bulletsY[i], bulletsX[i], bulletsY[i]-7, bulletsX[i]+14, bulletsY[i]);
		}
	} else {
		for (var i = 0; i < bulletsX.length; i++) {
			d.fillRect(bulletsX[i]-2.5, bulletsY[i] - 40, 5, 5);
		}
	}
	
	// Render enemy bullets
	for (var i = 0; i < enemiesBX.length; i++) {
		d.fillStyle = "#2222ff";
		d.fillRect(enemiesBX[i]-2.5, enemiesBY[i] - 40, 5, 5);
	}
	
	// Render Enemies
	for (var i = 0; i < enemiesX.length; i++) {
		if (enemiesT[i] == 1) {
			d.fillStyle = "#cc0000";
		} else if (enemiesT[i] == 2) {
			d.fillStyle = "#00cccc";
		} else if (enemiesT[i] == 3) {
			d.fillStyle = "#0000cc";
		} else if (enemiesT[i] == 4) {
			d.fillStyle = "#ff8800";
			if (enemyReload % 100 <= 67) {
							d.strokeStyle = "#ff8800";
				d.beginPath();
				d.arc(enemiesX[i], enemiesY[i], 50, 0, Math.PI);
				d.lineWidth = 10;
				d.stroke();
			}
		}
		d.beginPath();
		d.arc(enemiesX[i], enemiesY[i], 25, 0, Math.PI*2);
		d.fill();
	}
	
	// Render Power Ups
	for (var i = 0; i < powerX.length; i++) {
		d.fillStyle = "#cccc00";
		d.fillRect(powerX[i], powerY[i], 25, 35);
	}
	
	// Render Text	
	if (prevPWR != 0) {
		d.fillStyle = "#cccc00";
		d.font = "50px Arial";
		d.fillText(powersName[prevPWR], 500, 400);
	}
	
	if (gameOver && !won) {
		d.fillStyle = "#ff2222";
		d.font = "80px Arial";
		d.fillText("Game Over", 500, 400);
		d.font = "50px Arial";
		d.fillText("Level - " + levelPassed + " Score - " + score, 475, 500);
	} else if (gameOver && won) {
		d.fillStyle = "#22ff22";
		d.font = "80px Arial";
		d.fillText("You Win!", 500, 400);
		d.font = "50px Arial";
		d.fillText("Level - " + levelPassed + " Score - " + score, 425, 575);
		d.fillText("Press SPACE to go to the next level", 300, 500);
	}
	if (levelRunning != 0) {
		d.fillStyle = "#2222ff";
		d.font = "50px Arial";
		d.fillText("Score: " + score, 1100, 850);
		d.fillText("Lives: ", 50, 850);
		for (var i = 0; i < lives - 1; i++) {
			triangle(200+(65*i), 850, 225+(65*i), 800, 250+(65*i), 850, "#00cc00");
		}
	}
	/*for (var i = 0; i < enemiesX.length; i++) {
		for (var k = 100; k <= 1500; k++) {
		for (var j = 100; j <= 1500; j++) {
				if ((((j-enemiesX[i])*(j-enemiesX[i]))/2500) + (((k-enemiesY[i])*(k-enemiesY[i]))/2500) <=1 && k >= enemiesY[i]) {
					d.fillRect(j, k, 2, 2)
				}	}
		}}*/
 }

function shoot() {
	if (powers.includes(8)) {
		if (powers.includes(1)) {
			bulletsX[bulletsX.length] = px+265;
			bulletsY[bulletsX.length] = 800;
			bulletsX[bulletsX.length] = px+285;
			bulletsY[bulletsX.length] = 800;
		} else {
			bulletsX[bulletsX.length] = px+275;
			bulletsY[bulletsX.length] = 800;
		}
	}
	if (powers.includes(1)) {
		bulletsX[bulletsX.length] = px+15;
		bulletsY[bulletsX.length] = 800;
		bulletsX[bulletsX.length] = px+35;
		bulletsY[bulletsX.length] = 800;
	} else {
		bulletsX[bulletsX.length] = px+25;
		bulletsY[bulletsX.length] = 800;
	}
}

function enemyShoot(x, y) {
	var i = enemiesBX.length;
	enemiesBX[i] = x+25;
	enemiesBY[i] = y;
}

function newPowerUp(x, y) {
	powerX[powerX.length] = x;
	powerY[powerY.length] = y;
	powerType[powerType.length] = Math.ceil(Math.random() * 8);
	console.log(x);
}

function update() {
	//Update bullets
	if (reload != 0) {
		reload--;
	}
	for (var i = 0; i < bulletsX.length; i++) {
		if (powers.includes(7)) {
			bulletsY[i] -= 20;
		} else {
			bulletsY[i] -= 10;
		}
		if (bulletsY[i] <= 40) {
			bulletsX.splice(i, 1);
			bulletsY.splice(i, 1);
		}
	}


	// Update Enemies
	for (var i = 0; i < enemiesX.length; i++) {
		if (enemiesT[i] == 1) {
			enemiesX[i]+=12*enemiesD[i];
			enemiesDistance[i] += 12;
		} else if (enemiesT[i] == 2) {
			enemiesX[i]+= 18*enemiesD[i];
			enemiesDistance[i] += 18;
		} else if (enemiesT[i] == 3) {
			enemiesX[i]+= 8*enemiesD[i];
			enemiesDistance[i] += 8;
			if (enemyReload % 25 === 0) {
				enemyShoot(enemiesX[i] - 10, enemiesY[i] + 25);
			}
		} else if (enemiesT[i] == 4) {
			enemiesX[i]+= 10*enemiesD[i];
			enemiesDistance[i] += 10;
		}
		if (enemiesX[i] > 1350 || enemiesX[i] < 25) {
			enemiesY[i] += 50;
			enemiesD[i] *= -1;
			if (enemiesY[i] >= 900) {
				doGameOver();
				return;
			}
		}


		for (var j = 0; j <= bulletsX.length; j++) {
			if (enemiesT[i] == 4 && enemyReload % 100 <= 67) {
				if ((((bulletsX[j]-enemiesX[i])*(bulletsX[j]-enemiesX[i]))/2500) + (((bulletsY[j]-enemiesY[i]-30)*(bulletsY[j]-enemiesY[i]-30))/2500) <=1 && bulletsY[j]-20 >= enemiesY[i]) {
					bulletsX.splice(j, 1);
					bulletsY.splice(j, 1);
				}	
			}
			if (!powers.includes(7)) {
				if (enemiesX[i] - bulletsX[j] <= 35 && enemiesX[i] - bulletsX[j] >= -35 && enemiesY[i] - bulletsY[j] <= 35 && enemiesY[i] - bulletsY[j] >= -35) {

					if (!(enemiesT[i] == 4 && enemyReload % 100 <= 67)) {
						if (Math.random()*10 > 9) {
							newPowerUp(enemiesX[i], enemiesY[i]);
						}
						score += 20-Math.floor(enemiesDistance[i]/1000);
						enemiesX.splice(i, 1);
						enemiesY.splice(i, 1);
						enemiesD.splice(i, 1);
						enemiesT.splice(i, 1);
						enemiesDistance.splice(i, 1);
					}
					bulletsX.splice(j, 1);
					bulletsY.splice(j, 1);
					
				}
			} else if (enemiesX[i] - bulletsX[j] <= 45 && enemiesX[i] - bulletsX[j] >= -45 && enemiesY[i] - bulletsY[j] <= 55 && enemiesY[i] - bulletsY[j] >= -55) {
					score += 20-Math.floor(enemiesDistance[i]/1000);
					if (Math.random()*10 > 9) {
						newPowerUp(enemiesX[i], enemiesY[i]);
					}
					enemiesX.splice(i, 1);
					enemiesY.splice(i, 1);
					enemiesD.splice(i, 1);
					enemiesT.splice(i, 1);
				}
		}
		if (powers.includes(5) && enemiesX[i] - px <= 150 && enemiesX[i] - px >= -150 && enemiesY[i] - 450 >= 0) {
				enemiesX.splice(i, 1);
				enemiesY.splice(i, 1);
				enemiesD.splice(i, 1);
				enemiesT.splice(i, 1);
				score += 20-Math.floor(enemiesDistance[i]/1000);
		}
	}
	enemyGo++;
	if (levelRunning != 0 && enemyGo >= 7) {
		if (levelRunning < 10) {
			doLevel(levels[levelRunning-1]);
		} else {
			doLevel(randLevel);
		}
		enemyGo = 0;
	}
	if (levelRunning < 10) {
		if (!gameOver && !won && levelPlace > levels[levelRunning-1].length && enemiesX.length === 0) {
			doWin();
		}	
	} else {
		if (!gameOver && !won && levelPlace > randLevel.length && enemiesX.length === 0) {
			doWin();
		}
	}
	
	// Update enemy bullets
		enemyReload++;
	for (var i = 0; i < enemiesBX.length; i++) {
		enemiesBY[i] += 10;
		if (enemiesBY[i] >= 900) {
			enemiesBX.splice(i, 1);
			enemiesBY.splice(i, 1);
		}


		if (powers.includes(3)) {
			if ((((enemiesBX[i]-px-25)*(enemiesBX[i]-px-25))/2500) + (((enemiesBY[i]-785)*(enemiesBY[i]-785))/2500) <=1 && enemiesBY[i] <= 800) {	
					console.log(1);
					enemiesBX.splice(i, 1);
					enemiesBY.splice(i, 1);
			}
		}

		if (powers.includes(8)) {
			if (!powers.includes(6) && enemiesBX[i] - (px + 250) >= 0 && enemiesBX[i] - (px + 250) <= 50 && enemiesBY[i] >= 750 && enemiesBY[i] <= 800) {
				if (!powers.includes(3)) {
						for (var i = 0; i < powers.length; i++) {
							if (powers[i] == 8) {
								powers.splice(i, 1);
							}
						}
					
				} else {
					/*enemiesBX.splice(i, 1);
					enemiesBY.splice(i, 1);*/
				}
			} else if (powers.includes(6) && enemiesBX[i] - (px + 15 + 250) >= 0 && enemiesBX[i] - (px + 15 + 250) <= 20 && enemiesBY[i] >= 790 && enemiesBY[i] <= 800) {
				if (!powers.includes(3)) {
					for (var i = 0; i < powers.length; i++) {
						if (powers[i] == 8) {
							powers.splice(i, 1);
						}
					}
				} else {
					/*enemiesBX.splice(i, 1);
					enemiesBY.splice(i, 1);*/
				}
			}
		}
		
		if (!powers.includes(6) && enemiesBX[i] - px >= 0 && enemiesBX[i] - px <= 50 && enemiesBY[i] >= 750 && enemiesBY[i] <= 800) {
			if (!powers.includes(3)) {
				if (!powers.includes(8)) {
					lives--;
					enemiesBX.splice(i, 1);
					enemiesBY.splice(i, 1);
					if (lives <= 0) {
						doGameOver();
					} else {
						powers[powers.length] = 3;
						setTimeout(function(){var j = 0; while(powers[j] != 3){j++;}powers.splice(j, 1);}, 3000);
					}
				} else {
					px += 250;
					console.log(1);
					for (var i = 0; i < powers.length; i++) {
						if (powers[i] == 8) {
							powers.splice(i, 1);
						}
					}
				}
			} else {
				/*enemiesBX.splice(i, 1);
				enemiesBY.splice(i, 1);*/
			}
		} else if (powers.includes(6) && enemiesBX[i] - (px + 15) >= 0 && enemiesBX[i] - (px + 15) <= 20 && enemiesBY[i] >= 790 && enemiesBY[i] <= 800) {
			if (!powers.includes(3)) {
				if (!powers.includes(8)) {
					lives--;
					if (lives <= 0) {
						doGameOver();
					} else {
						powers[powers.length] = 3;
						setTimeout(function(){var j = 0; while(powers[j] != 3){j++;}powers.splice(j, 1);}, 3000);
					}
					/*enemiesBX.splice(i, 1);
					enemiesBY.splice(i, 1);*/
				} else {
					px += 250;
					console.log(1);
					for (var i = 0; i < powers.length; i++) {
						if (powers[i] == 8) {
							powers.splice(i, 1);
						}
					}
				}
			} else {
				enemiesBX.splice(i, 1);
				enemiesBY.splice(i, 1);
			}
		}	
	}
	
	
	// Update power ups
	for (var i = 0; i < powerX.length; i++) {
		powerY[i] += 5;
		if (powerY[i] > 710 && powerY[i] < 800 && Math.abs(powerX[i] - px) < 50 || (powerY[i] > 710 && powerY[i] < 800 && Math.abs(powerX[i] - (px + 250)) < 50)) {
			powers.push(powerType[i]);
			prevPWR = powerType[i];
			powerY.splice(i, 1);
			powerX.splice(i, 1);
			powerType.splice(i, 1);
			var prevNow = prevPWR;
			setTimeout(function(){if (prevNow==prevPWR) {prevPWR = 0;}}, 2500);
			if (prevNow != 8) {
				setTimeout(function(){var j = 0; while(powers[j] == 8){j++;}powers.splice(j, 1);}, 7500);
			}
		}
	}
	
}

document.addEventListener('keydown', function(event) {
	var code = event.keyCode;
	if (code == 68 && px < 1330) {
		if (powers.includes(4)) {
			px += 25;
		}
		if (powers.includes(6)) {
			px+=10;
		}
		px+= 25;
	}
	if (code == 65 && px > 10) {
		if (powers.includes(4)) {
			px -= 25;
		}
		if (powers.includes(6)) {
			px-=10;
		}
		px-= 25;
	}

	if (code == 69 && px < 1295 && fuel >= 50) {
		if (powers.includes(4)) {
			px += 25;
		}
		if (powers.includes(6)) {
			px+=10;
		}
		px+= 150;
		fuel = 0;
	}
	if (code == 81 && px > 65 && fuel >= 50) {
		if (powers.includes(4)) {
			px -= 25;
		}
		if (powers.includes(6)) {
			px-=10;
		}
		px-= 150;
		fuel = 0;
	}
});

document.addEventListener('keyup', function(event) {
	var code = event.keyCode;
	if (code == 32 && reload === 0 && levelRunning != 0) {
		shoot();
		if (powers.includes(2)) {
			reload += 13;
		} else {
			reload += 25;
		}
		if (powers.includes(7)) {
			reload += 25;
		}
	} else if (code == 32 && gameOver && won) {
		gameOver = false;
		won = false;
		levelPlace = 0;
		levelRunning = levelPassed+1;
		if (levelRunning < 10) { 
		} else {
			randomLevel();
		}
		score += 100;
	}
});